'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { useHunterStore } from '@/lib/store';
import { ATTRIBUTES } from '@/lib/game-logic';
import Navbar from '@/components/Navbar';
import StatsView from '@/components/StatsView';
import styles from './page.module.css';

export default function StatsPage() {
    const { profile, loading, getStats, updateScore, getOverallRank, getTheme } = useHunterStore();
    const router = useRouter();
    const [activeTab, setActiveTab] = useState<string>('Strength');

    useEffect(() => {
        if (!loading && !profile) {
            router.push('/');
        }
    }, [loading, profile, router]);

    if (loading || !profile) return null;

    const stats = getStats();
    const radarData = stats.map(s => s.percentage);
    const radarLabels = stats.map(s => s.name.substring(0, 3).toUpperCase());

    const currentStat = stats.find(s => s.name === activeTab) || stats[0];
    const currentAttr = ATTRIBUTES[currentStat.name];

    const themeRank = getTheme();
    const rankColor = `var(--rank-${themeRank.toLowerCase()})`;
    const overallRank = getOverallRank();

    const handleScoreChange = (testName: string, value: string) => {
        const numValue = parseFloat(value);
        if (!isNaN(numValue)) {
            updateScore(testName, numValue);
        }
    };

    return (
        <div className={styles.container}>
            <StatsView profile={profile} />
            <Navbar />
        </div>
    );
}
