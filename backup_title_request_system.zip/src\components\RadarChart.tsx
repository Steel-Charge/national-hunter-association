'use client';

import {
    Chart as ChartJS,
    RadialLinearScale,
    PointElement,
    LineElement,
    Filler,
    Tooltip,
    Legend,
} from 'chart.js';
import { Radar } from 'react-chartjs-2';

ChartJS.register(
    RadialLinearScale,
    PointElement,
    LineElement,
    Filler,
    Tooltip,
    Legend
);

interface RadarChartProps {
    labels: string[];
    data: number[];
    rankColor?: string; // Dynamic rank color
    comparisonData?: number[]; // Optional comparison data
    comparisonColor?: string; // Optional comparison color
}

export default function RadarChart({ labels, data, rankColor = '#00e5ff', comparisonData, comparisonColor = 'red' }: RadarChartProps) {
    const chartData = {
        labels: labels,
        datasets: [
            {
                label: 'Attributes',
                data: data,
                backgroundColor: 'transparent', // No fill
                borderColor: rankColor,
                borderWidth: 3, // Thicker line
                pointBackgroundColor: rankColor,
                pointBorderColor: '#fff',
                pointBorderWidth: 2, // Thicker point border
                pointRadius: 6, // Larger points
                pointHoverBackgroundColor: '#fff',
                pointHoverBorderColor: rankColor,
                pointHoverRadius: 8, // Larger on hover
                pointHoverBorderWidth: 3,
            },
            ...(comparisonData ? [{
                label: 'Comparison',
                data: comparisonData,
                backgroundColor: 'transparent',
                borderColor: comparisonColor, // Comparison color
                borderWidth: 2,
                pointBackgroundColor: comparisonColor,
                pointBorderColor: '#fff',
                pointBorderWidth: 2,
                pointRadius: 5,
                pointHoverBackgroundColor: '#fff',
                pointHoverBorderColor: comparisonColor,
                pointHoverRadius: 7,
                pointHoverBorderWidth: 3,
                borderDash: [5, 5], // Dashed line for comparison
            }] : []),
        ],
    };

    const options = {
        scales: {
            r: {
                angleLines: {
                    color: 'rgba(255, 255, 255, 0.15)', // Slightly more visible
                    lineWidth: 1,
                },
                grid: {
                    color: 'rgba(255, 255, 255, 0.15)', // Slightly more visible
                    lineWidth: 1,
                },
                pointLabels: {
                    color: '#ffffff', // Brighter labels
                    font: {
                        size: 14, // Larger font
                        weight: 'bold' as const,
                    },
                },
                ticks: {
                    display: false,
                    backdropColor: 'transparent',
                },
                suggestedMin: 0,
                suggestedMax: 100,
            },
        },
        plugins: {
            legend: {
                display: false,
            },
            tooltip: {
                enabled: true,
                backgroundColor: 'rgba(0, 0, 0, 0.8)',
                titleColor: rankColor,
                bodyColor: '#ffffff',
                borderColor: rankColor,
                borderWidth: 2,
                padding: 12,
                displayColors: false,
                callbacks: {
                    label: function (context: any) {
                        return `${context.parsed.r.toFixed(1)}%`;
                    }
                }
            },
        },
        maintainAspectRatio: false,
    };

    return (
        <div style={{ height: '300px', width: '100%' }}>
            <Radar data={chartData} options={options} />
        </div>
    );
}
